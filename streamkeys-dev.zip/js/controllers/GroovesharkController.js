(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
;(function() {
  "use strict";

  require("BaseController").init({
    playPause: "#play-pause",
    playNext: "#play-next",
    playPrev: "#play-prev",
    mute: "#volume"
  });
})();

},{"BaseController":2}],2:[function(require,module,exports){
;(function() {
  "use strict";

  var BaseController = function() { return this; };
  var sk_log = require("../modules/sk_log.js");

  BaseController.prototype.init = function(options) {
    this.name = document.location.hostname;

    //** Inject console log formatter **//

    //** Properties **//
    this.selector_playPause = options.playPause || null;
    this.selector_play = options.play || null;
    this.selector_pause = options.pause || null;
    this.selector_playNext = options.playNext || null;
    this.selector_playPrev = options.playPrev || null;
    this.selector_mute = options.mute || null;
    this.selector_iframe = options.iframe || null;

    //Optional. Style of play and pause buttons when they are NOT in use
    //EX: When a play button is in use, css class "playing" is added
    //In that case, set playStyle to "playing"
    this.playStyle = options.playStyle || null;
    this.pauseStyle = options.pauseStyle || null;

    this.iframe = (typeof options.iframe === "string");

    //Set to true if the play/pause buttons share the same element
    this.buttonSwitch = options.buttonSwitch || false;

    //Default listener sends actions to main document
    if(this.iframe) {
      this.attachFrameListener();
    } else {
      this.attachListener();
    }

    chrome.runtime.sendMessage({created: true}, function() {
      sk_log("Told BG we are created");
    });

    sk_log("SK content script loaded");
  };

  BaseController.prototype.injectScript = function(file) {
    var script = document.createElement("script");
    script.setAttribute("type", "text/javascript");
    if(file.url) {script.setAttribute("src", chrome.extension.getURL(file.url));}
    if(file.script) {script.innerHTML = file.script;}
    (document.head||document.documentElement).appendChild(script);
  };

  BaseController.prototype.isPlaying = function() {
    var playEl = document.querySelector(this.selector_play),
        displayStyle = "none",
        isPlaying = false;

    if(this.buttonSwitch) {
      //If playEl does not exist then it is currently playing
      isPlaying = (playEl === null);
    } else {
      //Check for play/pause style overrides
      if(this.playStyle && this.pauseStyle) {
        //Check if the class list contains the class that is only active when play button is playing
        isPlaying = playEl.classList.contains(this.playStyle);
      } else {
        //hack to get around sometimes not being able to read css properties that are not inline
        if (playEl.currentStyle) {
          displayStyle = playEl.currentStyle.display;
        } else if (window.getComputedStyle) {
          displayStyle = window.getComputedStyle(playEl, null).getPropertyValue("display");
        }
        isPlaying = (displayStyle == "none");
      }
    }

    sk_log("IsPlaying: " + isPlaying);
    return isPlaying;
  };

  //** Click inside document **//
  BaseController.prototype.click = function(selectorButton, action) {
    if(selectorButton === null) return sk_log("disabled", action);

    var ele = document.querySelector(selectorButton);

    try {
      ele.click();
      sk_log(action);
    } catch(e) {
      sk_log("Element not found for click.", selectorButton, true);
    }
  };

  //** Click inside an iframe **//
  BaseController.prototype.clickInFrame = function(selectorFrame, selectorButton, action) {
    if(selectorButton === null) return sk_log("disabled", action);

    var doc = document.querySelector(selectorFrame).contentWindow.document;
    if (!doc) return null;

    try {
      doc.querySelector(selectorButton).click();
      sk_log(action);
    } catch(e) {
      sk_log("Element not found for click.", selectorButton, true);
    }
  };

  //TODO: make isPlaying work with iframes
  BaseController.prototype.playPause = function() {
    if(this.selector_play !== null && this.selector_pause !== null) {
      if(this.isPlaying()) {
        this.click(this.selector_pause, "playPause");
      } else {
        this.click(this.selector_play, "playPause");
      }
    } else {
      if(this.iframe) this.clickInFrame(this.selector_iframe, this.selector_playPause, "playPause");
      else            this.click(this.selector_playPause, "playPause");
    }
  };

  BaseController.prototype.playNext = function() {
    //if(this.selector_playNext) {
      if(this.iframe) this.clickInFrame(this.selector_iframe, this.selector_playNext, "playNext");
      else            this.click(this.selector_playNext, "playNext");
    //}
  };

  BaseController.prototype.playPrev = function() {
    //if(this.selector_playPrev) {
      if(this.iframe) this.clickInFrame(this.selector_iframe, this.selector_playPrev, "playPrev");
      else            this.click(this.selector_playPrev, "playPrev");
    //}
  };

  BaseController.prototype.mute = function() {
    //if(this.selector_mute) {
      if(this.iframe) this.clickInFrame(this.selector_iframe, this.selector_mute, "mute");
      else            this.click(this.selector_mute, "mute");
    //}
  };

  BaseController.prototype.doRequest = function(request) {
    if(typeof request !== "undefined") {
      if(request.action == "playPause") this.playPause();
      if(request.action == "playNext") this.playNext();
      if(request.action == "playPrev") this.playPrev();
      if(request.action == "mute") this.mute();
    }
  };

  BaseController.prototype.doTestRequest = function(e) {
    if(e.detail && (e.detail == "playPause" || e.detail == "playNext" || e.detail == "playPrev" || e.detail == "mute")) {
      this.doRequest({action: e.detail});
    }
  };

  BaseController.prototype.attachListener = function() {
    chrome.runtime.onMessage.addListener(this.doRequest.bind(this));

    //Test event handler to simulate command presses
    document.addEventListener("streamkeys-test", this.doTestRequest.bind(this));

    sk_log("Attached listener for ", this);
  };

  BaseController.prototype.attachFrameListener = function() {
    chrome.runtime.onMessage.addListener(this.doRequest.bind(this));

    //Test event handler to simulate command presses
    document.addEventListener("streamkeys-test", this.doTestRequest.bind(this));

    sk_log("Attached frame listener for ", this);
  };


  var singleton = new BaseController();
  module.exports = singleton;
})();

},{"../modules/sk_log.js":3}],3:[function(require,module,exports){
;(function() {
  "use strict";

  module.exports = function(msg, obj, err) {
    obj = obj || "";
    if(err) { console.error("STREAMKEYS-ERROR: " + msg, obj); }
    else { console.log("STREAMKEYS-INFO: " + msg, obj); }
  };
})();

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hbGV4L3N0cmVhbWtleXMvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIi9Vc2Vycy9hbGV4L3N0cmVhbWtleXMvY29kZS9qcy9jb250cm9sbGVycy9Hcm9vdmVzaGFya0NvbnRyb2xsZXIuanMiLCIvVXNlcnMvYWxleC9zdHJlYW1rZXlzL2NvZGUvanMvbW9kdWxlcy9CYXNlQ29udHJvbGxlci5qcyIsIi9Vc2Vycy9hbGV4L3N0cmVhbWtleXMvY29kZS9qcy9tb2R1bGVzL3NrX2xvZy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCI7KGZ1bmN0aW9uKCkge1xuICBcInVzZSBzdHJpY3RcIjtcblxuICByZXF1aXJlKFwiQmFzZUNvbnRyb2xsZXJcIikuaW5pdCh7XG4gICAgcGxheVBhdXNlOiBcIiNwbGF5LXBhdXNlXCIsXG4gICAgcGxheU5leHQ6IFwiI3BsYXktbmV4dFwiLFxuICAgIHBsYXlQcmV2OiBcIiNwbGF5LXByZXZcIixcbiAgICBtdXRlOiBcIiN2b2x1bWVcIlxuICB9KTtcbn0pKCk7XG4iLCI7KGZ1bmN0aW9uKCkge1xuICBcInVzZSBzdHJpY3RcIjtcblxuICB2YXIgQmFzZUNvbnRyb2xsZXIgPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH07XG4gIHZhciBza19sb2cgPSByZXF1aXJlKFwiLi4vbW9kdWxlcy9za19sb2cuanNcIik7XG5cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLmluaXQgPSBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgdGhpcy5uYW1lID0gZG9jdW1lbnQubG9jYXRpb24uaG9zdG5hbWU7XG5cbiAgICAvLyoqIEluamVjdCBjb25zb2xlIGxvZyBmb3JtYXR0ZXIgKiovL1xuXG4gICAgLy8qKiBQcm9wZXJ0aWVzICoqLy9cbiAgICB0aGlzLnNlbGVjdG9yX3BsYXlQYXVzZSA9IG9wdGlvbnMucGxheVBhdXNlIHx8IG51bGw7XG4gICAgdGhpcy5zZWxlY3Rvcl9wbGF5ID0gb3B0aW9ucy5wbGF5IHx8IG51bGw7XG4gICAgdGhpcy5zZWxlY3Rvcl9wYXVzZSA9IG9wdGlvbnMucGF1c2UgfHwgbnVsbDtcbiAgICB0aGlzLnNlbGVjdG9yX3BsYXlOZXh0ID0gb3B0aW9ucy5wbGF5TmV4dCB8fCBudWxsO1xuICAgIHRoaXMuc2VsZWN0b3JfcGxheVByZXYgPSBvcHRpb25zLnBsYXlQcmV2IHx8IG51bGw7XG4gICAgdGhpcy5zZWxlY3Rvcl9tdXRlID0gb3B0aW9ucy5tdXRlIHx8IG51bGw7XG4gICAgdGhpcy5zZWxlY3Rvcl9pZnJhbWUgPSBvcHRpb25zLmlmcmFtZSB8fCBudWxsO1xuXG4gICAgLy9PcHRpb25hbC4gU3R5bGUgb2YgcGxheSBhbmQgcGF1c2UgYnV0dG9ucyB3aGVuIHRoZXkgYXJlIE5PVCBpbiB1c2VcbiAgICAvL0VYOiBXaGVuIGEgcGxheSBidXR0b24gaXMgaW4gdXNlLCBjc3MgY2xhc3MgXCJwbGF5aW5nXCIgaXMgYWRkZWRcbiAgICAvL0luIHRoYXQgY2FzZSwgc2V0IHBsYXlTdHlsZSB0byBcInBsYXlpbmdcIlxuICAgIHRoaXMucGxheVN0eWxlID0gb3B0aW9ucy5wbGF5U3R5bGUgfHwgbnVsbDtcbiAgICB0aGlzLnBhdXNlU3R5bGUgPSBvcHRpb25zLnBhdXNlU3R5bGUgfHwgbnVsbDtcblxuICAgIHRoaXMuaWZyYW1lID0gKHR5cGVvZiBvcHRpb25zLmlmcmFtZSA9PT0gXCJzdHJpbmdcIik7XG5cbiAgICAvL1NldCB0byB0cnVlIGlmIHRoZSBwbGF5L3BhdXNlIGJ1dHRvbnMgc2hhcmUgdGhlIHNhbWUgZWxlbWVudFxuICAgIHRoaXMuYnV0dG9uU3dpdGNoID0gb3B0aW9ucy5idXR0b25Td2l0Y2ggfHwgZmFsc2U7XG5cbiAgICAvL0RlZmF1bHQgbGlzdGVuZXIgc2VuZHMgYWN0aW9ucyB0byBtYWluIGRvY3VtZW50XG4gICAgaWYodGhpcy5pZnJhbWUpIHtcbiAgICAgIHRoaXMuYXR0YWNoRnJhbWVMaXN0ZW5lcigpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmF0dGFjaExpc3RlbmVyKCk7XG4gICAgfVxuXG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe2NyZWF0ZWQ6IHRydWV9LCBmdW5jdGlvbigpIHtcbiAgICAgIHNrX2xvZyhcIlRvbGQgQkcgd2UgYXJlIGNyZWF0ZWRcIik7XG4gICAgfSk7XG5cbiAgICBza19sb2coXCJTSyBjb250ZW50IHNjcmlwdCBsb2FkZWRcIik7XG4gIH07XG5cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLmluamVjdFNjcmlwdCA9IGZ1bmN0aW9uKGZpbGUpIHtcbiAgICB2YXIgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcbiAgICBzY3JpcHQuc2V0QXR0cmlidXRlKFwidHlwZVwiLCBcInRleHQvamF2YXNjcmlwdFwiKTtcbiAgICBpZihmaWxlLnVybCkge3NjcmlwdC5zZXRBdHRyaWJ1dGUoXCJzcmNcIiwgY2hyb21lLmV4dGVuc2lvbi5nZXRVUkwoZmlsZS51cmwpKTt9XG4gICAgaWYoZmlsZS5zY3JpcHQpIHtzY3JpcHQuaW5uZXJIVE1MID0gZmlsZS5zY3JpcHQ7fVxuICAgIChkb2N1bWVudC5oZWFkfHxkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLmFwcGVuZENoaWxkKHNjcmlwdCk7XG4gIH07XG5cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLmlzUGxheWluZyA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBwbGF5RWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHRoaXMuc2VsZWN0b3JfcGxheSksXG4gICAgICAgIGRpc3BsYXlTdHlsZSA9IFwibm9uZVwiLFxuICAgICAgICBpc1BsYXlpbmcgPSBmYWxzZTtcblxuICAgIGlmKHRoaXMuYnV0dG9uU3dpdGNoKSB7XG4gICAgICAvL0lmIHBsYXlFbCBkb2VzIG5vdCBleGlzdCB0aGVuIGl0IGlzIGN1cnJlbnRseSBwbGF5aW5nXG4gICAgICBpc1BsYXlpbmcgPSAocGxheUVsID09PSBudWxsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy9DaGVjayBmb3IgcGxheS9wYXVzZSBzdHlsZSBvdmVycmlkZXNcbiAgICAgIGlmKHRoaXMucGxheVN0eWxlICYmIHRoaXMucGF1c2VTdHlsZSkge1xuICAgICAgICAvL0NoZWNrIGlmIHRoZSBjbGFzcyBsaXN0IGNvbnRhaW5zIHRoZSBjbGFzcyB0aGF0IGlzIG9ubHkgYWN0aXZlIHdoZW4gcGxheSBidXR0b24gaXMgcGxheWluZ1xuICAgICAgICBpc1BsYXlpbmcgPSBwbGF5RWwuY2xhc3NMaXN0LmNvbnRhaW5zKHRoaXMucGxheVN0eWxlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vaGFjayB0byBnZXQgYXJvdW5kIHNvbWV0aW1lcyBub3QgYmVpbmcgYWJsZSB0byByZWFkIGNzcyBwcm9wZXJ0aWVzIHRoYXQgYXJlIG5vdCBpbmxpbmVcbiAgICAgICAgaWYgKHBsYXlFbC5jdXJyZW50U3R5bGUpIHtcbiAgICAgICAgICBkaXNwbGF5U3R5bGUgPSBwbGF5RWwuY3VycmVudFN0eWxlLmRpc3BsYXk7XG4gICAgICAgIH0gZWxzZSBpZiAod2luZG93LmdldENvbXB1dGVkU3R5bGUpIHtcbiAgICAgICAgICBkaXNwbGF5U3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShwbGF5RWwsIG51bGwpLmdldFByb3BlcnR5VmFsdWUoXCJkaXNwbGF5XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlzUGxheWluZyA9IChkaXNwbGF5U3R5bGUgPT0gXCJub25lXCIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHNrX2xvZyhcIklzUGxheWluZzogXCIgKyBpc1BsYXlpbmcpO1xuICAgIHJldHVybiBpc1BsYXlpbmc7XG4gIH07XG5cbiAgLy8qKiBDbGljayBpbnNpZGUgZG9jdW1lbnQgKiovL1xuICBCYXNlQ29udHJvbGxlci5wcm90b3R5cGUuY2xpY2sgPSBmdW5jdGlvbihzZWxlY3RvckJ1dHRvbiwgYWN0aW9uKSB7XG4gICAgaWYoc2VsZWN0b3JCdXR0b24gPT09IG51bGwpIHJldHVybiBza19sb2coXCJkaXNhYmxlZFwiLCBhY3Rpb24pO1xuXG4gICAgdmFyIGVsZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3JCdXR0b24pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGVsZS5jbGljaygpO1xuICAgICAgc2tfbG9nKGFjdGlvbik7XG4gICAgfSBjYXRjaChlKSB7XG4gICAgICBza19sb2coXCJFbGVtZW50IG5vdCBmb3VuZCBmb3IgY2xpY2suXCIsIHNlbGVjdG9yQnV0dG9uLCB0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8qKiBDbGljayBpbnNpZGUgYW4gaWZyYW1lICoqLy9cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLmNsaWNrSW5GcmFtZSA9IGZ1bmN0aW9uKHNlbGVjdG9yRnJhbWUsIHNlbGVjdG9yQnV0dG9uLCBhY3Rpb24pIHtcbiAgICBpZihzZWxlY3RvckJ1dHRvbiA9PT0gbnVsbCkgcmV0dXJuIHNrX2xvZyhcImRpc2FibGVkXCIsIGFjdGlvbik7XG5cbiAgICB2YXIgZG9jID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3RvckZyYW1lKS5jb250ZW50V2luZG93LmRvY3VtZW50O1xuICAgIGlmICghZG9jKSByZXR1cm4gbnVsbDtcblxuICAgIHRyeSB7XG4gICAgICBkb2MucXVlcnlTZWxlY3RvcihzZWxlY3RvckJ1dHRvbikuY2xpY2soKTtcbiAgICAgIHNrX2xvZyhhY3Rpb24pO1xuICAgIH0gY2F0Y2goZSkge1xuICAgICAgc2tfbG9nKFwiRWxlbWVudCBub3QgZm91bmQgZm9yIGNsaWNrLlwiLCBzZWxlY3RvckJ1dHRvbiwgdHJ1ZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vVE9ETzogbWFrZSBpc1BsYXlpbmcgd29yayB3aXRoIGlmcmFtZXNcbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLnBsYXlQYXVzZSA9IGZ1bmN0aW9uKCkge1xuICAgIGlmKHRoaXMuc2VsZWN0b3JfcGxheSAhPT0gbnVsbCAmJiB0aGlzLnNlbGVjdG9yX3BhdXNlICE9PSBudWxsKSB7XG4gICAgICBpZih0aGlzLmlzUGxheWluZygpKSB7XG4gICAgICAgIHRoaXMuY2xpY2sodGhpcy5zZWxlY3Rvcl9wYXVzZSwgXCJwbGF5UGF1c2VcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmNsaWNrKHRoaXMuc2VsZWN0b3JfcGxheSwgXCJwbGF5UGF1c2VcIik7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmKHRoaXMuaWZyYW1lKSB0aGlzLmNsaWNrSW5GcmFtZSh0aGlzLnNlbGVjdG9yX2lmcmFtZSwgdGhpcy5zZWxlY3Rvcl9wbGF5UGF1c2UsIFwicGxheVBhdXNlXCIpO1xuICAgICAgZWxzZSAgICAgICAgICAgIHRoaXMuY2xpY2sodGhpcy5zZWxlY3Rvcl9wbGF5UGF1c2UsIFwicGxheVBhdXNlXCIpO1xuICAgIH1cbiAgfTtcblxuICBCYXNlQ29udHJvbGxlci5wcm90b3R5cGUucGxheU5leHQgPSBmdW5jdGlvbigpIHtcbiAgICAvL2lmKHRoaXMuc2VsZWN0b3JfcGxheU5leHQpIHtcbiAgICAgIGlmKHRoaXMuaWZyYW1lKSB0aGlzLmNsaWNrSW5GcmFtZSh0aGlzLnNlbGVjdG9yX2lmcmFtZSwgdGhpcy5zZWxlY3Rvcl9wbGF5TmV4dCwgXCJwbGF5TmV4dFwiKTtcbiAgICAgIGVsc2UgICAgICAgICAgICB0aGlzLmNsaWNrKHRoaXMuc2VsZWN0b3JfcGxheU5leHQsIFwicGxheU5leHRcIik7XG4gICAgLy99XG4gIH07XG5cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLnBsYXlQcmV2ID0gZnVuY3Rpb24oKSB7XG4gICAgLy9pZih0aGlzLnNlbGVjdG9yX3BsYXlQcmV2KSB7XG4gICAgICBpZih0aGlzLmlmcmFtZSkgdGhpcy5jbGlja0luRnJhbWUodGhpcy5zZWxlY3Rvcl9pZnJhbWUsIHRoaXMuc2VsZWN0b3JfcGxheVByZXYsIFwicGxheVByZXZcIik7XG4gICAgICBlbHNlICAgICAgICAgICAgdGhpcy5jbGljayh0aGlzLnNlbGVjdG9yX3BsYXlQcmV2LCBcInBsYXlQcmV2XCIpO1xuICAgIC8vfVxuICB9O1xuXG4gIEJhc2VDb250cm9sbGVyLnByb3RvdHlwZS5tdXRlID0gZnVuY3Rpb24oKSB7XG4gICAgLy9pZih0aGlzLnNlbGVjdG9yX211dGUpIHtcbiAgICAgIGlmKHRoaXMuaWZyYW1lKSB0aGlzLmNsaWNrSW5GcmFtZSh0aGlzLnNlbGVjdG9yX2lmcmFtZSwgdGhpcy5zZWxlY3Rvcl9tdXRlLCBcIm11dGVcIik7XG4gICAgICBlbHNlICAgICAgICAgICAgdGhpcy5jbGljayh0aGlzLnNlbGVjdG9yX211dGUsIFwibXV0ZVwiKTtcbiAgICAvL31cbiAgfTtcblxuICBCYXNlQ29udHJvbGxlci5wcm90b3R5cGUuZG9SZXF1ZXN0ID0gZnVuY3Rpb24ocmVxdWVzdCkge1xuICAgIGlmKHR5cGVvZiByZXF1ZXN0ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBpZihyZXF1ZXN0LmFjdGlvbiA9PSBcInBsYXlQYXVzZVwiKSB0aGlzLnBsYXlQYXVzZSgpO1xuICAgICAgaWYocmVxdWVzdC5hY3Rpb24gPT0gXCJwbGF5TmV4dFwiKSB0aGlzLnBsYXlOZXh0KCk7XG4gICAgICBpZihyZXF1ZXN0LmFjdGlvbiA9PSBcInBsYXlQcmV2XCIpIHRoaXMucGxheVByZXYoKTtcbiAgICAgIGlmKHJlcXVlc3QuYWN0aW9uID09IFwibXV0ZVwiKSB0aGlzLm11dGUoKTtcbiAgICB9XG4gIH07XG5cbiAgQmFzZUNvbnRyb2xsZXIucHJvdG90eXBlLmRvVGVzdFJlcXVlc3QgPSBmdW5jdGlvbihlKSB7XG4gICAgaWYoZS5kZXRhaWwgJiYgKGUuZGV0YWlsID09IFwicGxheVBhdXNlXCIgfHwgZS5kZXRhaWwgPT0gXCJwbGF5TmV4dFwiIHx8IGUuZGV0YWlsID09IFwicGxheVByZXZcIiB8fCBlLmRldGFpbCA9PSBcIm11dGVcIikpIHtcbiAgICAgIHRoaXMuZG9SZXF1ZXN0KHthY3Rpb246IGUuZGV0YWlsfSk7XG4gICAgfVxuICB9O1xuXG4gIEJhc2VDb250cm9sbGVyLnByb3RvdHlwZS5hdHRhY2hMaXN0ZW5lciA9IGZ1bmN0aW9uKCkge1xuICAgIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcih0aGlzLmRvUmVxdWVzdC5iaW5kKHRoaXMpKTtcblxuICAgIC8vVGVzdCBldmVudCBoYW5kbGVyIHRvIHNpbXVsYXRlIGNvbW1hbmQgcHJlc3Nlc1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzdHJlYW1rZXlzLXRlc3RcIiwgdGhpcy5kb1Rlc3RSZXF1ZXN0LmJpbmQodGhpcykpO1xuXG4gICAgc2tfbG9nKFwiQXR0YWNoZWQgbGlzdGVuZXIgZm9yIFwiLCB0aGlzKTtcbiAgfTtcblxuICBCYXNlQ29udHJvbGxlci5wcm90b3R5cGUuYXR0YWNoRnJhbWVMaXN0ZW5lciA9IGZ1bmN0aW9uKCkge1xuICAgIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcih0aGlzLmRvUmVxdWVzdC5iaW5kKHRoaXMpKTtcblxuICAgIC8vVGVzdCBldmVudCBoYW5kbGVyIHRvIHNpbXVsYXRlIGNvbW1hbmQgcHJlc3Nlc1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzdHJlYW1rZXlzLXRlc3RcIiwgdGhpcy5kb1Rlc3RSZXF1ZXN0LmJpbmQodGhpcykpO1xuXG4gICAgc2tfbG9nKFwiQXR0YWNoZWQgZnJhbWUgbGlzdGVuZXIgZm9yIFwiLCB0aGlzKTtcbiAgfTtcblxuXG4gIHZhciBzaW5nbGV0b24gPSBuZXcgQmFzZUNvbnRyb2xsZXIoKTtcbiAgbW9kdWxlLmV4cG9ydHMgPSBzaW5nbGV0b247XG59KSgpO1xuIiwiOyhmdW5jdGlvbigpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbihtc2csIG9iaiwgZXJyKSB7XG4gICAgb2JqID0gb2JqIHx8IFwiXCI7XG4gICAgaWYoZXJyKSB7IGNvbnNvbGUuZXJyb3IoXCJTVFJFQU1LRVlTLUVSUk9SOiBcIiArIG1zZywgb2JqKTsgfVxuICAgIGVsc2UgeyBjb25zb2xlLmxvZyhcIlNUUkVBTUtFWVMtSU5GTzogXCIgKyBtc2csIG9iaik7IH1cbiAgfTtcbn0pKCk7XG4iXX0=
